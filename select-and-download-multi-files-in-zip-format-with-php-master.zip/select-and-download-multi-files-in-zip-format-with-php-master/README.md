# upload-images-and-files-with-php-class
Upload images and files Class with PHP


See detailed Documentation <a href="https://learncodeweb.com/php/select-and-download-multi-files-in-zip-format-with-php/" target="_blank">Click here</a>

Online View <a href="https://learncodeweb.com/demo/php/select-and-download-multi-files-in-zip-format-with-php/index.php" target="_blank">View Demo</a>
